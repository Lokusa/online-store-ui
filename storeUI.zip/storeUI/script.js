const products = [
  { id: 1, name: "Hoodie", price: 500 },
  { id: 2, name: "Jeans", price: 700 },
  { id: 3, name: "T-Shirt", price: 300 },
  { id: 4, name: "Shoes", price: 900 }
];

let cart = [];

function login() {
  const username = document.getElementById("username").value;
  if (username.trim()) {
    document.getElementById("user-name").textContent = username;
    document.getElementById("login-section").style.display = "none";
    document.getElementById("shop-section").style.display = "block";
    displayCatalogue();
  } else {
    alert("Please enter your name.");
  }
}

function displayCatalogue() {
  const catalogue = document.getElementById("catalogue");
  catalogue.innerHTML = "";
  products.forEach(product => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <h4>${product.name}</h4>
      <p>R${product.price}</p>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
    `;
    catalogue.appendChild(div);
  });
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById("cart-list");
  const totalElem = document.getElementById("total");
  cartList.innerHTML = "";
  let total = 0;
  cart.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = `${item.name} - R${item.price}`;
    cartList.appendChild(li);
    total += item.price;
  });
  totalElem.textContent = total;
}

function pay() {
  if (cart.length === 0) {
    alert("Cart is empty.");
    return;
  }
  alert("Payment successful! Thank you for your purchase.");
  clearCart();
}

function clearCart() {
  cart = [];
  updateCart();
}
